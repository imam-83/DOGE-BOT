# ChikaBotv2

<h1 align="center">ソファヤン<img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>Sofyan AMV Was Hare!</h1>

<p align="center">
<img src="https://ibb.co/r5wpr0n" width="100%" alt="API Giphy logo"/>
</p>

- 🌱 I’m currently learning **nothing**.

- 👀 I m currently focusing on **JavaScript**.


<p align="center">
  <img src="https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript" />
  <img src="https://img.shields.io/badge/-Node.js-black?style=flat-square&logo=Node.js" />
  <img src="https://img.shields.io/badge/-Git-black?style=flat-square&logo=git" />
  <img src="https://img.shields.io/badge/-GitHub-black?style=flat-square&logo=github" /> <br>
  <img src="https://img.shields.io/badge/-Python-black?style=flat-square&logo=python" />
</p>

<p align="center">
  <a href="https://github.com/SofyanAMV09"><img src="https://github-readme-stats.vercel.app/api?username=SofyanAMV09&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&icon_color=fff&hide_border=true&show_icons=true" /></a>
</p>

<p align="center">
  <a href="https://github.com/SofyanAMV09"><img src="https://github-readme-stats.vercel.app/api/top-langs?username=SofyanAMV09&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&hide_border=true&show_icons=true&layout=compact" /></a>
</p>

<p align="center">
  <a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=SofyanAMV09&theme=onedark" /></a>
</p>

<p align="center">
   <img src="https://github-readme-streak-stats.herokuapp.com/?user=SofyanAMV09" />
</p>

<p align="center">
  <a href="https://youtu.be/WgeItwiifYs"><img src="https://img.shields.io/badge/YouTube-SofyanAMV09-ff0000?style=for-the-badge&logo=youtube&logoColor=ff0000&link=https://youtu.be/n9fUrhPf5-8" /></a>
  <a name=hendra759&label=VIEWS&style=flat-square&color=orange" />
  
  ## Install the dependencies:
Before running the below command, make sure you're in the project directory that
you've just cloned!!

```bash
> pkg update && pkg upgrade 
> pkg install nodejs
> pkg install tesseract 
> git clone https://github.com/SofyanAMV09/ChikaBotv2
> cd ChikaBotv2
> bash install.sh
```

### Usage
```bash
> npm start
```


</p> 
 #sosial media


* [`WhatsApp Admin `](https://wa.me/6281227825649)

* [`Chika Bot `](https://wa.me/6282363352693)


